public class Lados{

    public Vertices verIni;
    public Vertices verFin;

    Lados(Vertices verIni , Vertices verFin){
        this.verIni = verIni;
        this.verFin = verFin;
    }

}